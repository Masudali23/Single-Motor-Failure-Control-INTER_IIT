#!/bin/bash

# Get the current position of the drone
current_pos=$(rostopic echo -n 1 /iris/ground_truth/position)

# Extract x, y, z coordinates
current_x=$(echo "$current_pos" | grep -m 1 x: | awk '{print $2}')
current_y=$(echo "$current_pos" | grep -m 1 y: | awk '{print $2}')
current_z=$(echo "$current_pos" | grep -m 1 z: | awk '{print $2}')

# Gradually decrease altitude to land the drone
# rostopic pub -1 /iris/reference_pos geometry_msgs/Point -- $current_x $current_y $(echo "$current_z - 0.5" | bc)
# sleep 2.0

# rostopic pub -1 /iris/reference_pos geometry_msgs/Point -- $current_x $current_y $(echo "$current_z - 1.0" | bc)
# sleep 2.0

rostopic pub -1 /iris/reference_pos geometry_msgs/Point -- $current_x $current_y 0
sleep 2.0
    
# Decrease motor speeds

# Send emergency kill signal to stop the rotors
rostopic pub -1 /iris/emergency_kill std_msgs/Empty --