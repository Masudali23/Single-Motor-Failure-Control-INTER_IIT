#!/usr/bin/env python

import rospy
from std_msgs.msg import Float32

def motor_callback(motor_num, data):
    rospy.loginfo(f"Motor {motor_num} speed: {data.data}")

def check_motors():
    rospy.init_node('motor_speed_checker', anonymous=True)
    rospy.loginfo("Motor speed checker started...")
    
    # Subscribe to individual motor speeds
    for i in range(4):
        rospy.Subscriber(f'/iris/motor_speed/{i}', Float32, 
                        lambda data, num=i: motor_callback(num, data))
    
    rospy.loginfo("Monitoring individual motor speeds...")
    rospy.spin()

if __name__ == '__main__':
    try:
        check_motors()
    except rospy.ROSInterruptException:
        pass