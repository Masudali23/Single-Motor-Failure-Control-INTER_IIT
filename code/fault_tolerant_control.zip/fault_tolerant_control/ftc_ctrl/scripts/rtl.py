#!/usr/bin/env python3

import rospy
import math
from geometry_msgs.msg import Point, PointStamped
from std_msgs.msg import Int32

def get_current_position():
    current_pos = rospy.wait_for_message('/iris/ground_truth/position', PointStamped)
    return current_pos.point.x, current_pos.point.y, current_pos.point.z

def is_at_position(current, target, tolerance=0.1):
    return all(abs(c - t) < tolerance for c, t in zip(current, target))

def rtl():
    rospy.init_node('rtl_drone', anonymous=True)
    pos_pub = rospy.Publisher('/iris/reference_pos', Point, queue_size=10)
    status_pub = rospy.Publisher('/drone/land_status', Int32, queue_size=10)
    
    rate = rospy.Rate(10)  # 10 Hz
    
    # Ensure RTL start is published and received
    rospy.sleep(0.5)  # Wait for publishers to be ready
    status_pub.publish(0)  # Signal RTL start
    rospy.sleep(0.5)  # Make sure signal is received
    
    # Get current position
    current_x, current_y, current_z = get_current_position()
    
    # Phase 1: Go to position above home (0,0)
    while not rospy.is_shutdown():
        pos_pub.publish(Point(x=0.0, y=0.0, z=current_z))
        x, y, z = get_current_position()
        
        if is_at_position((x, y), (0.0, 0.0)):
            rospy.loginfo("Reached position above home")
            break
        rate.sleep()
    
    # Phase 2: Descent to ground
    while not rospy.is_shutdown():
        pos_pub.publish(Point(x=0.0, y=0.0, z=0.5))
        x, y, z = get_current_position()
        
        if z > 0.1:  # Still descending
            status_pub.publish(0)
        else:  # Landed
            rospy.loginfo("RTL complete - Drone has landed")
            status_pub.publish(1)
            break
        rate.sleep()

if __name__ == '__main__':
    try:
        rtl()
    except rospy.ROSInterruptException:
        pass
