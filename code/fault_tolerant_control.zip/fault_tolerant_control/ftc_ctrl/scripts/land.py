#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Point, PointStamped
from std_msgs.msg import Int32

def get_current_position():
    current_pos = rospy.wait_for_message('/iris/ground_truth/position', PointStamped)
    return current_pos.point.x, current_pos.point.y, current_pos.point.z

def land_drone():
    rospy.init_node('land_drone', anonymous=True)
    pos_pub = rospy.Publisher('/iris/reference_pos', Point, queue_size=10)
    status_pub = rospy.Publisher('/drone/land_status', Int32, queue_size=10)
    
    rate = rospy.Rate(10)  # 10 Hz
    target_x, target_y, _ = get_current_position()
    target_z = 0.0
    
    status_pub.publish(0)  # Indicate that the drone is not landing yet
    
    while not rospy.is_shutdown():
        pos_pub.publish(Point(x=target_x, y=target_y, z=target_z))
        current_x, current_y, current_z = get_current_position()
        
        if current_z > 0.1:  # Drone is still in the air
            status_pub.publish(0)   
        else:  # Close enough to the ground
            rospy.loginfo("Drone has landed")
            status_pub.publish(1)
            break
        
        rate.sleep()

if __name__ == '__main__':
    try:
        land_drone()
    except rospy.ROSInterruptException:
        pass
